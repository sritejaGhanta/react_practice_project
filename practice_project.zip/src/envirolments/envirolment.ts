export default {
    API_URL: "http://localhost:4200",
    SITE_URL: "http://localhost:432/",
    TOKEN_KEY: "access_token"
}