import { memo, Suspense, useDeferredValue, useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { LoadBreadCrumb } from "../../core/genaral/genaral.methos"
import { DataTable } from "simple-datatables"
import axiosInstance from "../../service/http.server";
import API_END_POINTS from "../../service/core.api.end.points"
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-quartz.css";
import { AgGridReact } from "ag-grid-react"
import './list.component.css';
import { ColDef } from "ag-grid-community"
import { useDebounce } from 'use-debounce';

function List(prop: any) {

    const [users, setUser] = useState([]);
    // const [settings, setSettings] = useState({});
    // const [pages, setPages] = useState([]);
    let settings = {};
    let pages = [];
    let totalPages = 0;
    let displayedPages =[]



    const gridOptions = {
        checkboxSelection: true,
        context: true
    }

    const [keyword, setKeyword] = useState(null);
    const key = useDebounce(keyword, 500);

    const apiPayload = {
        limit: 50,
        page: 1,
        keyword: key[0]
    };

    const callListApi = (params = null) => {
        axiosInstance.post(API_END_POINTS.users.list, apiPayload).then(e => {
            setUser(e.data);
            settings = e.settings;
            totalPages = Math.ceil(e.settings.count / e.settings.per_page);
            pages = Array.from({ length: totalPages }, (_, index) => index + 1)
            // setSettings(e.settings);
            // setPages(Array.from({ length: totalPages }, (_, index) => index + 1))


            const totalPages = Math.ceil(totalItems / itemsPerPage);

            
                const pages: (number | string)[] = [];

                if (totalPages <= 7) {
                    // Show all pages if total pages are <= 7
                    for (let i = 1; i <= totalPages; i++) {
                        pages.push(i);
                    }
                } else {
                    // Always show the first 3 pages
                    pages.push(1, 2, 3);

                    // Add '...' if the current page is far from the first 3 pages
                    if (settings.curr_page > 4) {
                        pages.push("...");
                    }

                    // Show the current page or a middle range
                    if (settings.curr_page > 3 && settings.curr_page < totalPages - 2) {
                        pages.push(settings.curr_page);
                    }

                    // Add '...' if the current page is far from the last 3 pages
                    if (settings.curr_page < totalPages - 3) {
                        pages.push("...");
                    }

                    // Always show the last 3 pages
                    pages.push(totalPages - 2, totalPages - 1, totalPages);
                }

                displayedPages =  pages;
        })

    }
    const ActionBtn = (prop) => {
        console.log(prop);
        const deleteUser = () => {
            const id = prop.data.users_id;
            axiosInstance.delete(API_END_POINTS.users.delete + '/' + id).then(e => {
                if (e.settings.success) {

                    callListApi()
                }
            })

        }
        return <>
            <Link className="btn btn-success me-1" to={"/users/" + prop.data.users_id}> <i className="bi bi-pencil-fill"></i></Link>
            <button className="btn btn-danger" onClick={deleteUser}> <i className="bi bi-trash"></i></button>

        </>
    }

    const colDefs: ColDef = [
        // {
        //     // field: 'users_id', 
        //     headerName: "#",
        //     flex: 1,
        //     checkboxSelection: true,
        //     sortable: false,

        // },
        {
            headerName: "Name",
            field: 'name',
            flex: 1,
            minWidth: 250,
            sortable: true,
        },
        {
            headerName: 'Email',
            field: "email",
            headerClass: "ag-header-center",
            minWidth: 250,
            flex: 1,
            sortable: true,
        },
        {
            headerName: 'Phone Number',
            field: "phoneno",
            headerClass: "ag-header-center",
            cellClass: "text-center",
            minWidth: 250,
            flex: 1,
            sortable: true,
        },
        {
            headerName: 'Added Date',
            field: "added_date",
            headerClass: "ag-header-center",
            cellClass: "text-center",
            minWidth: 100,
            flex: 1,
            sortable: true,
            type: "datecolumn"
        },
        {
            headerName: 'Status',
            field: "status",
            headerClass: "ag-header-center",
            cellClass: "text-center",
            minWidth: 100,
            flex: 1,
            sortable: true,
        },
        {
            headerName: 'Action',
            minWidth: 10,
            headerClass: "ag-header-center",
            cellClass: "text-center",
            flex: 1,
            sortable: false,
            cellRenderer: ActionBtn
        },
    ];

    const onPageChange = (page: number) => {
        console.log(page)
    }

    useEffect(() => {
        callListApi()
    }, [key[0]])

    return (
        <>
            {LoadBreadCrumb("Users", [{ name: 'Users' }])}
            <div className="row">
                <div className="col-lg-12">

                    <div className="card">
                        <div className="card-body">
                            <div className="d-flex justify-content-between align-items-center mb-4">
                                <h5 className="card-title">Users List</h5>
                                <div className="d-flex align-items-center justify-content-center">
                                    <div className="input-group">
                                        <input
                                            type="text"
                                            className="form-control"
                                            value={keyword}
                                            onChange={e => setKeyword(e.target.value)}
                                            placeholder="Search"
                                        />

                                        {keyword ?
                                            <button className="input-group-text" onClick={() => setKeyword('')}><i className="bi bi-x-circle"></i></button> :
                                            <button className="input-group-text"><i className="bi bi-search"></i></button>
                                        }
                                    </div>

                                    <button className="btn btn-secondary ms-2 " onClick={callListApi} title="Refresh">
                                        <i className="bi bi-arrow-clockwise "></i>
                                    </button>
                                    <Link className="btn btn-secondary ms-2 " onClick={callListApi} title="Add User" to={"/users/add"}>
                                        <i className="bi bi-file-earmark-plus "></i>
                                    </Link>
                                </div>

                            </div>
                            <div
                                className="ag-theme-quartz" // applying the Data Grid theme
                                style={{ height: 500 }} // the Data Grid will fill the size of the parent container
                            >
                                <AgGridReact
                                    rowData={users}
                                    columnDefs={colDefs}
                                    rowHeight='55'
                                    gridOptions={gridOptions}
                                />
                            </div>
                            <div className="pagination-container">
                                {/* First and Previous Buttons */}
                                <button
                                    className="pagination-button"
                                    disabled={settings.curr_page === 1}
                                    onClick={() => onPageChange(1)}
                                >
                                    &laquo;
                                </button>
                                <button
                                    className="pagination-button"
                                    disabled={settings.curr_page === 1}
                                    onClick={() => onPageChange(settings.curr_page - 1)}
                                >
                                    &lt;
                                </button>

                                {/* Page Numbers */}
                                {displayedPages.map((page, index) =>
                                    typeof page === "number" ? (
                                        <button
                                            key={index}
                                            className={`pagination-page ${page === settings.curr_page ? "active" : ""
                                                }`}
                                            onClick={() => onPageChange(page)}
                                        >
                                            {page}
                                        </button>
                                    ) : (
                                        <span key={index} className="pagination-ellipsis">
                                            ...
                                        </span>
                                    )
                                )}

                                {/* Next and Last Buttons */}
                                <button
                                    className="pagination-button"
                                    disabled={settings.curr_page === totalPages}
                                    onClick={() => onPageChange(settings.curr_page + 1)}
                                >
                                    &gt;
                                </button>
                                <button
                                    className="pagination-button"
                                    disabled={settings.curr_page === totalPages}
                                    onClick={() => onPageChange(totalPages)}
                                >
                                    &raquo;
                                </button>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
            <script type="module">
            </script>
        </>
    )
}



export default memo(List)
