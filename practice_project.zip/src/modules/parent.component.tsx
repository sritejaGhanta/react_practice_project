
// // import common styles
// import 'bootstrap/dist/css/bootstrap.css';
// import "../../assets/vendor/bootstrap/css/bootstrap.min.css";
// import "../../assets/vendor/bootstrap-icons/bootstrap-icons.css";
// import "../../assets/vendor/boxicons/css/boxicons.min.css";
// import "../../assets/vendor/quill/quill.snow.css";
// import "../../assets/vendor/quill/quill.bubble.css";
// import "../../assets/vendor/remixicon/remixicon.css";
// import "../../assets/vendor/simple-datatables/style.css";
// import "../../assets/css/style.css";

// // import common js files
// import "../../assets/vendor/apexcharts/apexcharts.min.js";
// import "../../assets/vendor/bootstrap/js/bootstrap.bundle.min.js";
// import "../../assets/vendor/chart.js/chart.umd.js";
// import "../../assets/vendor/echarts/echarts.min.js";
// import "../../assets/vendor/quill/quill.js";
// import "../../assets/vendor/simple-datatables/simple-datatables.js";
// import "../../assets/vendor/tinymce/tinymce.min.js";
// import "../../assets/vendor/php-email-form/validate.js";

// const scripts = [
//     '../../assets/js/main.js'
// ];


// import './parent.component.css'
// import { memo, useEffect } from "react";

// import Header from "./head-footers/head.component.js"
// import Footer from "./head-footers/footer.component.js"

// import React from 'react';

// function loadJavaScriptFiles() {
//     // Load JavaScript files dynamically
//     scripts.forEach((script) => {
//         import(script) 
//     });
// }

// function ParentComponent(porp: any) {
//     useEffect(loadJavaScriptFiles, [])

//     return (
//         <>
//             <Header />
//             <Footer />

//         </>
//     )
// }
// // export class ParentComponent extends React.Component {
// //     constructor(prop: any) {
// //         super(prop)
// //     }


    
    
    
    
// //     render() {
// //         useEffect(loadJavaScriptFiles, []);
// //         return (
// //             <>
// //                 <Header />
// //                 {/* using conditional redaring */}
// //                 <AppRoutingComponent />
// //                 <Footer />
// //             </>
// //         )
// //     }

// // }


// export default memo(ParentComponent)
