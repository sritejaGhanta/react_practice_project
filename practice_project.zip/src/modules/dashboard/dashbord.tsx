import { memo } from "react";
import { LoadBreadCrumb } from "../../core/genaral/genaral.methos";

function Dashbord() {
    return <>
        {LoadBreadCrumb('Dashboard', [])}
    </>
}

export default memo(Dashbord)